//
//  global.h
//  BTLETools
//
//  Created by Tijn Kooijmans on 03/04/14.
//
//
//#define BTLETools_global_h
let IS_IPAD = (UIDevice.currentDevice().userInterfaceIdiom == .Pad)
let bigCellHeight: CGFloat = 100

let defaultCellHeight: CGFloat = 88

var defaultStoryboard: String = "Main_TV"

let CELL_BOLD_TITLE_FONT = UIFont.systemFontOfSize(38)
let CELL_TITLE_FONT = UIFont.systemFontOfSize(38)
let CELL_SUBTITLE_FONT = UIFont.systemFontOfSize(38)
let bigCellHeight: CGFloat = 50

let defaultCellHeight: CGFloat = 44

var defaultStoryboard: String = "Main"

let CELL_BOLD_TITLE_FONT = UIFont.boldSystemFontOfSize(18)
let CELL_TITLE_FONT = UIFont.systemFontOfSize(18)
let CELL_SUBTITLE_FONT = UIFont.systemFontOfSize(12)