//
//  BTLEDevice.h
//  BTLETools
//
//  Created by Tijn Kooijmans on 10-04-12.
//  Copyright (c) 2012 Studio Sophisti. All rights reserved.
//
import UIKit
import CoreBluetooth
class BTLEDevice: NSObject {
    var peripheralRef: CBPeripheral
    var advertisementData: [NSObject : AnyObject]
    var manager: CBCentralManager
    var advServices: String
    var brcData: String

    func advertisedServices() -> String {
        if advServices {
            return advServices
        }
        var str: NSMutableString = NSMutableString()
        if (advertisementData[CBAdvertisementDataServiceUUIDsKey] as! String) {
            str.appendString("Services: ")
            var services: [AnyObject] = (advertisementData[CBAdvertisementDataServiceUUIDsKey] as! [AnyObject])
            if services.count {
                for serviceUUID: CBUUID in services {
                    str.appendFormat("%@, ", serviceUUID.representativeString())
                }
                str.appendString("xxx")
                str.replaceOccurrencesOfString(", xxx", withString: "", options: 0, range: NSMakeRange(0, str.characters.count))
                advServices = str
            }
            else {
                advServices = "No advertised services"
            }
        }
        else {
            advServices = "No advertised services"
        }
        return advServices
    }

    func txPower() -> Int {
        if (advertisementData[CBAdvertisementDataTxPowerLevelKey] as! String) {
            return CInt((advertisementData[CBAdvertisementDataTxPowerLevelKey] as! String))!
        }
        return -1
    }

    func channel() -> Int {
        if (advertisementData["kCBAdvDataChannel"] as! String) {
            return CInt((advertisementData["kCBAdvDataChannel"] as! String))!
        }
        return -1
    }

    func isConnectable() -> Bool {
        return CBool((advertisementData[CBAdvertisementDataIsConnectable] as! String))!
    }

    func name() -> String {
        var deviceName: String? = nil
        if (deviceName = (advertisementData[CBAdvertisementDataLocalNameKey] as! String)) && deviceName!.characters.count {
            return deviceName!
        }
        else if (deviceName = peripheralRef.name()) && deviceName!.characters.count {
            return deviceName!
        }

        return "<no name>"
    }

    func broadcastData() -> String {
        if brcData {
            return brcData
        }
        if (advertisementData[CBAdvertisementDataManufacturerDataKey] as! String) {
            var raw: String = (advertisementData[CBAdvertisementDataManufacturerDataKey] as! String).description
            raw = raw.stringByReplacingOccurrencesOfString("<", withString: "")
            raw = raw.stringByReplacingOccurrencesOfString(">", withString: "")
            brcData = "Broadcasted data: 0x\(raw)"
        }
        else {
            brcData = "No broadcasted data"
        }
        return brcData
    }
    var peripheralRef: CBPeripheral
    var advertisementData: [NSObject : AnyObject]
    var manager: CBCentralManager
    var RSSI: Int
}
//
//  BTLEDevice.m
//  BTLETools
//
//  Created by Tijn Kooijmans on 10-04-12.
//  Copyright (c) 2012 Studio Sophisti. All rights reserved.
//