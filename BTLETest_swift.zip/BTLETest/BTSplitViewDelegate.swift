//
//  BTSplitViewController.h
//  BTLETools
//
//  Created by Tijn Kooijmans on 03/04/14.
//
//
import UIKit
class BTSplitViewDelegate: UISplitViewController {

    convenience override init(nibName nibNameOrNil: String!, bundle nibBundleOrNil: NSBundle!) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        if self != nil {
            // Custom initialization
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func splitViewController(svc: UISplitViewController, shouldHideViewController vc: UIViewController, inOrientation orientation: UIInterfaceOrientation) -> Bool {
        return false
    }

    func splitViewController(svc: UISplitViewController, willHideViewController aViewController: UIViewController, withBarButtonItem barButtonItem: UIBarButtonItem, forPopoverController pc: UIPopoverController) {
        barButtonItem.title = "Devices"
        svc.viewControllers[1].topViewController().navigationItem.leftBarButtonItem = barButtonItem
    }
}
//
//  BTSplitViewController.m
//  BTLETools
//
//  Created by Tijn Kooijmans on 03/04/14.
//
//