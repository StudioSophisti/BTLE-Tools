//
//  DevicesViewController.h
//  BTLETools
//
//  Created by Tijn Kooijmans on 10-04-12.
//  Copyright (c) 2012 Studio Sophisti. All rights reserved.
//
import UIKit
import CoreBluetooth
class DevicesViewController: UITableViewController, CBCentralManagerDelegate, CBPeripheralDelegate {
    var manager: CBCentralManager
    var devices: [AnyObject]
    var scanning: Bool
    var scanTimer: NSTimer
    var deviceVc: DeviceViewController
    var servicesVc: ServicesViewController


    override func viewDidLoad() {
        super.viewDidLoad()
        manager = CBCentralManager(delegate: self, queue: nil)
        devices = [AnyObject](minimumCapacity: 10)
        self.title = "BLE Scan Results"
        //self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemRefresh target:self action:@selector(actionScan)];
        NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: "updateRSSI", userInfo: nil, repeats: true)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "actionScan", name: UIApplicationDidBecomeActiveNotification, object: nil)
        deviceVc = ((self.splitViewController.viewControllers[1] as! UINavigationController).viewControllers[0] as! DeviceViewController)
    }

    override func didRotateFromInterfaceOrientation(fromInterfaceOrientation: UIInterfaceOrientation) {
        self.tableView.reloadData()
    }

    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
    }

    func actionStopScanning() {
        scanTimer = nil
        scanning = false
        manager.stopScan()
        self.actionScan()
        self.tableView.reloadData()
    }

    func addPeripheral(peripheral: CBPeripheral) -> BTLEDevice {
        var device: BTLEDevice = BTLEDevice()
        device.peripheralRef = peripheral
        device.manager = manager
        peripheral.delegate = self
        devices.append(device)
        return device
    }

    func updateRSSI() {
        for device: BTLEDevice in devices {
            if device.peripheralRef.state == .Connected {
                device.peripheralRef.readRSSI()
                device.RSSI = device.peripheralRef.RSSI
            }
        }
        deviceVc.updateRSSI()
        self.tableView.reloadData()
    }

    func actionScan() {
        if manager.state == .PoweredOff {
            var alert: UIAlertController = UIAlertController.alertControllerWithTitle("Bluetooth disabled", message: "Please enable Bluetooth in your device settings to use this app.", preferredStyle: .Alert)
            alert.addAction(UIAlertAction.actionWithTitle("OK", style: .Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: { _ in })
            return
        }
        if scanTimer {
            scanTimer.invalidate()
        }
        scanning = true
        var newDevices: [AnyObject] = [AnyObject](capacity: 10)
        for device: BTLEDevice in devices {
            if device.peripheralRef.state != .Disconnected {
                newDevices.append(device)
            }
        }
        devices = newDevices
        self.tableView.reloadData()
        manager.stopScan()
        manager.scanForPeripheralsWithServices(nil, options: nil)
        scanTimer = NSTimer.scheduledTimerWithTimeInterval(60, target: self, selector: "actionStopScanning", userInfo: nil, repeats: false)
    }

    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var n: Int = devices.count
        if scanning {
            n++
        }
        return n
    }

    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        if scanning && indexPath.row == devices.count {
            var loadingIdentifier: String = "LoadingCellIdentifier"
            var cell: UITableViewCell = (tableView.dequeueReusableCellWithIdentifier(loadingIdentifier) as! UITableViewCell)
            if cell == nil {
                cell = UITableViewCell(style: .Default, reuseIdentifier: loadingIdentifier)
                cell.selectionStyle = .None
                var loadingView: UIActivityIndicatorView = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
                loadingView.tintColor = UIColor.lightGrayColor()
                var loadingView: UIActivityIndicatorView = UIActivityIndicatorView(activityIndicatorStyle: .Gray)
                loadingView.tag = 8
                cell.userInteractionEnabled = false
                cell.contentView.addSubview(loadingView)
            }
            (cell.viewWithTag(8) as! UIActivityIndicatorView).center = CGPointMake(self.view.frame.size.width / 2, bigCellHeight / 2)
            (cell.viewWithTag(8) as! UIActivityIndicatorView).startAnimating()
            return cell
        }
        var device: BTLEDevice = devices[indexPath.row]
        var CellIdentifier: String = "DeviceCell"
        var cell: UITableViewCell = tableView.dequeueReusableCellWithIdentifier(CellIdentifier)
        cell.textLabel.text = device.name()
        cell.detailTextLabel.text = "Signal strength: \(device.RSSI.intValue) dB"
        if device.channel() > -1 {
            cell.detailTextLabel.text = "\(cell.detailTextLabel.text!), channel \(device.channel())"
        }
        if device.peripheralRef.state == .Connected {
            cell.imageView.image = UIImage(named: "bt_icon.png")
        }
        else {
            cell.imageView.image = UIImage(named: "bt_icon_grey.png")
        }
        return cell
    }

    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return bigCellHeight
    }

    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        self.splitViewController.viewControllers[1].viewControllers = [deviceVc]
        deviceVc.device = devices[indexPath.row]
        deviceVc.updateViews()
        deviceVc.title = deviceVc.device.name()
        if IS_IPAD {
            self.splitViewController.viewControllers[1].viewControllers = [deviceVc]
            deviceVc.device = devices[indexPath.row]
            deviceVc.updateViews()
            deviceVc.title = deviceVc.device.name()
        }
        else {
            var sb: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            deviceVc = sb.instantiateViewControllerWithIdentifier("deviceViewController")
            deviceVc.device = devices[indexPath.row]
            self.navigationController!.pushViewController(deviceVc, animated: true)
        }
    }

    func centralManagerDidUpdateState(central: CBCentralManager) {
        NSLog("Central manager changed state: %ld", central.state)
        if central.state == .PoweredOn {
            self.actionScan()
        }
    }

    func centralManager(central: CBCentralManager, didRetrievePeripherals peripherals: [AnyObject]) {
        NSLog("%ld periphirals retrieved", peripherals.count)
    }

    func centralManager(central: CBCentralManager, didRetrieveConnectedPeripherals peripherals: [AnyObject]) {
        for peripheral: CBPeripheral in peripherals {
            NSLog("Periphiral discovered: %@", peripheral.name)
            var found: Bool = false
            for device: BTLEDevice in devices {
                if (device.peripheralRef.identifier.UUIDString() == peripheral.identifier.UUIDString()) {
                    found = true
                }
            }
            if !found {
                self.addPeripheral(peripheral)
            }
        }
        self.tableView.reloadData()
    }

    func centralManager(central: CBCentralManager, didDiscoverPeripheral peripheral: CBPeripheral, advertisementData: [NSObject : AnyObject], RSSI: Int) {
        NSLog("Periphiral discovered: %@, signal strength: %d", peripheral.name, RSSI.intValue)
        for device: BTLEDevice in devices {
            if (device.peripheralRef.identifier.UUIDString() == peripheral.identifier.UUIDString()) {
                return
            }
        }
        var device: BTLEDevice = self.addPeripheral(peripheral)
        device.advertisementData = advertisementData
        device.RSSI = RSSI
        self.tableView.reloadData()
    }

    func centralManager(central: CBCentralManager, didConnectPeripheral peripheral: CBPeripheral) {
        NSLog("Periphiral connected: %@", peripheral.name)
        NSNotificationCenter.defaultCenter().postNotificationName("connection_changed", object: nil)
        self.tableView.reloadData()
    }

    func centralManager(central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: NSError) {
        NSLog("Periphiral disconnected: %@", peripheral.name)
        NSNotificationCenter.defaultCenter().postNotificationName("connection_changed", object: nil)
        self.tableView.reloadData()
    }

    func centralManager(central: CBCentralManager, didFailToConnectPeripheral peripheral: CBPeripheral, error: NSError) {
        NSLog("Periphiral failed to connect: %@", peripheral.name)
        var alert: UIAlertController = UIAlertController.alertControllerWithTitle("Failed to connect", message: error.localizedDescription, preferredStyle: .Alert)
        alert.addAction(UIAlertAction.actionWithTitle("OK", style: .Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: { _ in })
    }

    func actionScan() {
    }
}
//
//  DevicesViewController.m
//  BTLETools
//
//  Created by Tijn Kooijmans on 10-04-12.
//  Copyright (c) 2012 Studio Sophisti. All rights reserved.
//