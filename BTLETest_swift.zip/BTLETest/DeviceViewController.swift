//
//  DeviceViewController.h
//  BTLETools
//
//  Created by Tijn Kooijmans on 10-04-12.
//  Copyright (c) 2012 Studio Sophisti. All rights reserved.
//
import UIKit
class DeviceViewController: UITableViewController {
    var lblName: IBOutlet UILabel
    var lblTxPower: IBOutlet UILabel
    var lblUUID: IBOutlet UILabel
    var lblServices: IBOutlet UILabel
    var lblData: IBOutlet UILabel
    var actConnect: IBOutlet UIActivityIndicatorView
    var btnConnect: IBOutlet UIButton
    var btImageView: IBOutlet UIImageView
    var servicesCell: IBOutlet UITableViewCell
    var connectCell: IBOutlet UITableViewCell

    var device: BTLEDevice

    @IBAction func actionConnect(sender: AnyObject) {
        if device.peripheralRef.state != .Disconnected {
            device.manager.cancelPeripheralConnection(device.peripheralRef)
        }
        else {
            device.manager.connectPeripheral(device.peripheralRef, options: nil)
        }
        self.updateViews()
    }

    func updateViews() {
        self.updateLabels()
        if device.peripheralRef.state == .Connected {
            connectCell.accessoryView = nil
            connectCell.textLabel.text = "Disconnect"
        }
        else if device.peripheralRef.state == .Connecting {
            connectCell.accessoryView = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
            connectCell.accessoryView.tintColor = UIColor.lightGrayColor()
            connectCell.accessoryView = UIActivityIndicatorView(activityIndicatorStyle: .Gray)
            (connectCell.accessoryView as! UIActivityIndicatorView).startAnimating()
            connectCell.textLabel.text = "Connecting..."
        }
        else if !device.isConnectable() {
            connectCell.textLabel.text = "Not Connectable"
        }
        else {
            connectCell.accessoryView = nil
            connectCell.textLabel.text = "Connect"
        }

        self.tableView.reloadData()
    }

    func updateRSSI() {
        var str: NSMutableString = NSMutableString()
        str.appendFormat("RSSI: %d", CInt(device.RSSI)!)
        if device.txPower() > -1 {
            str.appendFormat(", TX Power: %d", device.txPower())
        }
        if device.channel() > -1 {
            str.appendFormat(", Channel: %d", device.channel())
        }
        lblTxPower.text = str
    }

    func updateLabels() {
        lblName.text = device.name()
        lblUUID.text = "UUID: \(device.peripheralRef.identifier.UUIDString())"
        lblServices.text = device.advertisedServices()
        lblData.text = device.broadcastData()
        self.updateRSSI()
    }

    func dealloc() {
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Device Data"
        self.updateLabels()
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "updateViews", name: "connection_changed", object: nil)
    }

    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.updateViews()
    }

    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        if !device {
            return 0
        }
        return 3
    }

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 2 {
            return 2
        }
        else if section == 1 && device.peripheralRef.state == .Connected {
            return 2
        }
        else if section == 1 {
            return 1
        }
        else {
            return 3
        }

    }

    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        if indexPath.section == 1 && indexPath.row == 1 {
            var servicesVc: ServicesViewController? = nil
            var sb: UIStoryboard = UIStoryboard(name: defaultStoryboard, bundle: nil)
            servicesVc = sb.instantiateViewControllerWithIdentifier("servicesViewController")
            self.navigationController!.pushViewController(servicesVc!, animated: true)
            servicesVc.device = device.peripheralRef
            self.device.peripheralRef.delegate = servicesVc!
            device.peripheralRef.discoverServices(nil)
        }
        else if indexPath.section == 1 && indexPath.row == 0 && device.isConnectable() {
            self.actionConnect(nil)
        }

    }

    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if indexPath.section == 0 && indexPath.row == 1 {
            var constraintSize: CGSize = CGSizeMake(self.view.bounds.size.width - 40, MAXFLOAT)
            var labelSize: CGSize = lblUUID.text!.boundingRectWithSize(constraintSize, options: ([.UsesLineFragmentOrigin, .UsesFontLeading]), attributes: [NSFontAttributeName: CELL_TITLE_FONT], context: nil).size
            return labelSize.height + 20
        }
        else if indexPath.section == 2 && indexPath.row == 0 {
            var constraintSize: CGSize = CGSizeMake(self.view.bounds.size.width - 40, MAXFLOAT)
            var labelSize: CGSize = lblServices.text!.boundingRectWithSize(constraintSize, options: ([.UsesLineFragmentOrigin, .UsesFontLeading]), attributes: [NSFontAttributeName: CELL_TITLE_FONT], context: nil).size
            return labelSize.height + 20
        }
        else if indexPath.section == 2 && indexPath.row == 1 {
            var constraintSize: CGSize = CGSizeMake(self.view.bounds.size.width - 40, MAXFLOAT)
            var labelSize: CGSize = lblData.text!.boundingRectWithSize(constraintSize, options: ([.UsesLineFragmentOrigin, .UsesFontLeading]), attributes: [NSFontAttributeName: CELL_TITLE_FONT], context: nil).size
            return labelSize.height + 20
        }
        else {
            return defaultCellHeight
        }

    }
}
//
//  DeviceViewController.m
//  BTLETools
//
//  Created by Tijn Kooijmans on 10-04-12.
//  Copyright (c) 2012 Studio Sophisti. All rights reserved.
//