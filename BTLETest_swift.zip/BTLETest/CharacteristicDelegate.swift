//
//  CharacteristicDelegate.h
//  BTLETools
//
//  Created by Tijn Kooijmans on 26-11-12.
//
//
import Foundation
import CoreBluetooth
protocol CharacteristicDelegate: NSObject {
    func characteristic(characteristic: CBCharacteristic, changedWithData data: NSData)
}