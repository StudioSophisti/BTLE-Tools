//
//  CBUUID+String.h
//  BTLETools
//
//  Created by Tijn Kooijmans on 04/04/14.
//
//
import CoreBluetooth
extension CBUUID {
    func representativeString() -> String {
        var data: NSData = self.data()
        var bytesToConvert: Int = data.characters.count
        let uuidBytes: UInt8 = data.bytes()
        var outputString: NSMutableString = NSMutableString(capacity: 16)
        for var currentByteIndex = 0; currentByteIndex < bytesToConvert; currentByteIndex++ {
            switch currentByteIndex {
                case 3, 5, 7, 9:
                    outputString.appendFormat("%02x-", uuidBytes[currentByteIndex])
                default:
                    outputString.appendFormat("%02x", uuidBytes[currentByteIndex])
            }
        }
        return outputString
    }
}
//
//  CBUUID+String.m
//  BTLETools
//
//  Created by Tijn Kooijmans on 04/04/14.
//
//