//
//  CBCharacteristic+Description.h
//  BTLETools
//
//  Created by Tijn Kooijmans on 14-11-12.
//
//
import CoreBluetooth
extension CBCharacteristic {
    func characteristicName() -> String {
        var title: String = "\(self.UUID)"
        var index: NSRange = title.rangeOfString("(<")
        if index.location != NSNotFound {
            if title.characters.count > 20 {
                // 128 bit uuid
                return "0x\(title.substringWithRange(NSMakeRange(index.location + 2, 35)))"
            }
            else {
                    // 16 bit uuid
                var key: String = "0x\(title.substringWithRange(NSMakeRange(index.location + 2, 4)).uppercaseString)"
                var value: String = NSLocalizedStringFromTable(key, "characteristics", "")
                if (key == value) {
                    value = "Unknown UUID"
                }
                return "\(key): \(value)"
            }
        }
        return title.stringByReplacingOccurrencesOfString("Unknown", withString: "Unknown UUID:")
    }

    func hexString() -> String {
        if !self.value {
            return "-"
        }
        var raw: String = "0x\(self.value)"
        raw = raw.stringByReplacingOccurrencesOfString("<", withString: "")
        raw = raw.stringByReplacingOccurrencesOfString(">", withString: "")
        return raw
    }

    func asciiString() -> String {
        if !self.value {
            return "-"
        }
        var ascii: String = String(data: self.value, encoding: NSASCIIStringEncoding)
        return ascii
    }
}
//
//  CBCharacteristic+Description.m
//  BTLETools
//
//  Created by Tijn Kooijmans on 14-11-12.
//
//