//
//  ServicesViewController.h
//  BTLETools
//
//  Created by Tijn Kooijmans on 10-04-12.
//  Copyright (c) 2012 Studio Sophisti. All rights reserved.
//
import UIKit
import CoreBluetooth
class ServicesViewController: UITableViewController, CBPeripheralDelegate {
    var device: CBPeripheral
    var loading: Bool
    var charVc: CharacteristicViewController

    var device: CBPeripheral

    func updateTable() {
        self.tableView.reloadData()
    }

    func dealloc() {
        device.delegate = nil
        NSNotificationCenter.defaultCenter().removeObserver(self.tableView)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        NSNotificationCenter.defaultCenter().addObserver(self.tableView, selector: "reloadData", name: "connection_changed", object: nil)
        self.title = "Services"
    }

    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        charVc = nil
    }

    override func didRotateFromInterfaceOrientation(fromInterfaceOrientation: UIInterfaceOrientation) {
        self.tableView.reloadData()
    }

    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        if loading || !device || device.state == .Disconnected {
            return 1
        }
        return device.services.count
    }

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if loading || !device || device.state == .Disconnected {
            return 1
        }
        var service: CBService = device.services[section]
        return service.characteristics.count
    }

    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if loading || !device || device.state == .Disconnected {
            return defaultCellHeight
        }
        var service: CBService = device.services[indexPath.section]
        var characterstic: CBCharacteristic = service.characteristics[indexPath.row]
        var cellText: String = "Value: \(characterstic.hexString())\nAscii: \(characterstic.asciiString())"
        var cellFont: UIFont = UIFont.systemFontOfSize(14)
        var constraintSize: CGSize = CGSizeMake(self.view.bounds.size.width - 40, MAXFLOAT)
        var labelSize: CGSize = cellText.boundingRectWithSize(constraintSize, options: ([.UsesLineFragmentOrigin, .UsesFontLeading]), attributes: [NSFontAttributeName: cellFont], context: nil).size
        return labelSize.height + defaultCellHeight - 13
    }

    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        if loading != nil {
            var loadingIdentifier: String = "LoadingCellIdentifier"
            var cell: UITableViewCell = (tableView.dequeueReusableCellWithIdentifier(loadingIdentifier) as! UITableViewCell)
            if cell == nil {
                cell = UITableViewCell(style: .Default, reuseIdentifier: loadingIdentifier)
                cell.selectionStyle = .None
                var loadingView: UIActivityIndicatorView = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
                loadingView.tintColor = UIColor.lightGrayColor()
                var loadingView: UIActivityIndicatorView = UIActivityIndicatorView(activityIndicatorStyle: .Gray)
                loadingView.tag = 8
                cell.contentView.addSubview(loadingView)
            }
            (cell.viewWithTag(8) as! UIActivityIndicatorView).center = CGPointMake(self.view.frame.size.width / 2, defaultCellHeight / 2)
            (cell.viewWithTag(8) as! UIActivityIndicatorView).startAnimating()
            return cell
        }
        else if !device || device.state == .Disconnected {
            var nodDeviceIdentifier: String = "NoDeviceCellIdentifier"
            var cell: UITableViewCell = (tableView.dequeueReusableCellWithIdentifier(nodDeviceIdentifier) as! UITableViewCell)
            if cell == nil {
                cell = UITableViewCell(style: .Default, reuseIdentifier: nodDeviceIdentifier)
                cell.selectionStyle = .None
                cell.textLabel.font = CELL_BOLD_TITLE_FONT
                if !device {
                    cell.textLabel.text = "No device connected"
                }
                else {
                    cell.textLabel.text = "Disconnected"
                }
            }
            return cell
        }

        var service: CBService = device.services[indexPath.section]
        var characterstic: CBCharacteristic = service.characteristics[indexPath.row]
        var CellIdentifier: String = "CharacteristicCell"
        var cell: UITableViewCell = tableView.dequeueReusableCellWithIdentifier(CellIdentifier)
        cell.textLabel.text = characterstic.characteristicName()
        cell.detailTextLabel.text = "Value: \(characterstic.hexString())\nAscii: \(characterstic.asciiString())"
        cell.detailTextLabel.sizeToFit()
        return cell
    }

    func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String {
        if loading || device.state == .Disconnected {
            return ""
        }
        var service: CBService = device.services[section]
        return service.serviceName()
    }

    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        if !device || device.state == .Disconnected || loading {
            return
        }
        var service: CBService = device.services[indexPath.section]
        var characterstic: CBCharacteristic = service.characteristics[indexPath.row]
        var sb: UIStoryboard = UIStoryboard(name: defaultStoryboard, bundle: nil)
        charVc = sb.instantiateViewControllerWithIdentifier("characteristicViewController")
        charVc.characteristic = characterstic
        self.navigationController!.pushViewController(charVc, animated: true)
    }

    func peripheral(peripheral: CBPeripheral, didDiscoverServices error: NSError) {
        //NSLog(@"Services dicovered for peripheral %@:", peripheral.name);
        for service: CBService in peripheral.services {
            NSLog("%@", service.UUID)
            peripheral.discoverCharacteristics(nil, forService: service)
        }
        loading = false
        self.tableView.reloadData()
    }

    func peripheral(peripheral: CBPeripheral, didDiscoverCharacteristicsForService service: CBService, error: NSError) {
        //NSLog(@"characteristics dicovered for service %@:", service.UUID);
        for characteristic: CBCharacteristic in service.characteristics {
            NSLog("%@", characteristic.UUID)
            peripheral.setNotifyValue(true, forCharacteristic: characteristic)
            peripheral.readValueForCharacteristic(characteristic)
        }
        self.tableView.reloadData()
    }

    func peripheral(peripheral: CBPeripheral, didUpdateValueForCharacteristic characteristic: CBCharacteristic, error: NSError) {
        //NSLog(@"Updated value for characteristic %@: %@", characteristic.UUID, characteristic.value);
        self.tableView.reloadData()
        if charVc {
            charVc.updatedValue()
        }
    }
}
//
//  ServicesViewController.m
//  BTLETools
//
//  Created by Tijn Kooijmans on 10-04-12.
//  Copyright (c) 2012 Studio Sophisti. All rights reserved.
//