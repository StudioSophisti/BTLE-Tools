//
//  CharacteristicViewControllerViewController.h
//  BTLETools
//
//  Created by Tijn Kooijmans on 11-04-12.
//  Copyright (c) 2012 Studio Sophisti. All rights reserved.
//
import UIKit
import CoreBluetooth
class CharacteristicViewController: UITableViewController, UITextFieldDelegate {
    var lblName: IBOutlet UILabel
    var lblValue: IBOutlet UILabel
    var lblAscii: IBOutlet UILabel
    var lblLatency: IBOutlet UILabel
    var lblProperties: IBOutlet UILabel
    var lblLive: IBOutlet UILabel
    var txtSend: IBOutlet UITextField
    var vwWrite: IBOutlet UIView
    var liveUpdate: Bool
    var requestTime: Double
    var delegate: CharacteristicDelegate
    var characteristic: CBCharacteristic

    var characteristic: CBCharacteristic

    func updatedValue() {
        var lag: Double = NSDate().timeIntervalSince1970 - requestTime
        lblLatency.text = String(format: "Read Latency: %.3f s", lag)
        lblValue.text = "Value (HEX): \(characteristic.hexString())"
        lblAscii.text = "Value (ASCII): \(characteristic.asciiString())"
        if liveUpdate {
            requestTime = NSDate().timeIntervalSince1970
            characteristic.service.peripheral.readValueForCharacteristic(characteristic)
        }
        if delegate && delegate.respondsToSelector("characteristic:changedWithData:") {
            delegate.characteristic(characteristic, changedWithData: characteristic.value)
        }
    }

    @IBAction func actionLiveUpdate(sender: AnyObject) {
        liveUpdate = !liveUpdate
        if liveUpdate {
            //self.navigationItem.rightBarButtonItem.enabled = NO;
            requestTime = NSDate().timeIntervalSince1970
            characteristic.service.peripheral.readValueForCharacteristic(characteristic)
            lblLive.text = "Stop updating"
        }
        else {
            //self.navigationItem.rightBarButtonItem.enabled = YES;
            lblLive.text = "Live updating"
        }
    }

    @IBAction func actionSend(sender: AnyObject) {
        var byteStrings: [AnyObject] = txtSend.text!.componentsSeparatedByString(":")
        var data: NSMutableData = NSMutableData.dataWithCapacity(byteStrings.count)
        var failed: Bool = false
        if byteStrings.count == 0 {
            failed = true
        }
        for byteString: String in byteStrings {
            if byteString.characters.count != 2 {
                failed = true
            }
            var a: UInt = 0
            var scanner: NSScanner = NSScanner(string: byteString)
            if scanner.scanHexInt(a) {
                var b: UInt8 = UInt8(a)
                data.appendBytes(b, length: 1)
            }
        }
        if !failed {
            if characteristic.properties & .WriteWithoutResponse {
                characteristic.service.peripheral.writeValue(data, forCharacteristic: characteristic, type: CBCharacteristicWriteWithoutResponse)
            }
            else if characteristic.properties & .Write {
                characteristic.service.peripheral.writeValue(data, forCharacteristic: characteristic, type: CBCharacteristicWriteWithResponse)
            }

            txtSend.resignFirstResponder()
        }
        else {
            var alert: UIAlertController = UIAlertController.alertControllerWithTitle("Format error", message: "Please match the following formatting: 'ff:ff:ff:ff:...'", preferredStyle: .Alert)
            alert.addAction(UIAlertAction.actionWithTitle("OK", style: .Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: { _ in })
        }
    }

    func dealloc() {
        delegate = nil
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Characteristic"
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .Refresh, target: self, action: "actionReload:")
        lblName.text = characteristic.characteristicName()
        lblValue.text = "Value (HEX): \(characteristic.hexString())"
        lblAscii.text = "Value (ASCII): \(characteristic.asciiString())"
        requestTime = NSDate().timeIntervalSince1970
        characteristic.service.peripheral.readValueForCharacteristic(characteristic)
        var propertiesString: NSMutableString = NSMutableString(string: "Properties: ")
        if characteristic.properties & .Read {
            propertiesString.appendString("Readable, ")
        }
        if characteristic.properties & .Write {
            propertiesString.appendString("Writable, ")
        }
        if characteristic.properties & .WriteWithoutResponse {
            propertiesString.appendString("Writable without response, ")
        }
        if characteristic.properties & .Notify {
            propertiesString.appendString("Notifying, ")
        }
        if characteristic.properties & .Indicate {
            propertiesString.appendString("Indicating, ")
        }
        if characteristic.properties & .ExtendedProperties {
            propertiesString.appendString("Extended properties, ")
        }
        if characteristic.properties & .Broadcast {
            propertiesString.appendString("Broadcasting, ")
        }
        if characteristic.properties & .AuthenticatedSignedWrites {
            propertiesString.appendString("Authenticated Signed Writes, ")
        }
        propertiesString.appendString("xxx")
        propertiesString.replaceOccurrencesOfString(", xxx", withString: "", options: 0, range: NSMakeRange(0, propertiesString.characters.count))
        lblProperties.text = propertiesString
        lblProperties.sizeToFit()
        if (characteristic.properties & .Write) || (characteristic.properties & .WriteWithoutResponse) {
            vwWrite.hidden = false
        }
        else {
            vwWrite.hidden = true
        }
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "connectionChanged", name: "connection_changed", object: nil)
    }

    override func viewDidAppear(animated: Bool) {
        delegate = nil
        liveUpdate = false
        lblLive.text = "Live updating"
    }

    func connectionChanged() {
        if characteristic.service.peripheral.state == .Disconnected {
            lblName.text = "Disconnected"
        }
        self.tableView.reloadData()
    }

    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        if characteristic.service.peripheral.state == .Disconnected {
            return 1
        }
        if (characteristic.properties & .Write) || (characteristic.properties & .WriteWithoutResponse) {
            return 3
        }
        else {
            return 2
        }
    }

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if characteristic.service.peripheral.state == .Disconnected {
            return 1
        }
        if section == 0 {
            return 4
        }
        else {
            return 2
        }
    }

    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        if indexPath.section == 1 && indexPath.row == 1 {
            self.actionLiveUpdate(nil)
        }
        else if indexPath.section == 2 && indexPath.row == 1 {
            self.actionSend(nil)
        }

    }

    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if indexPath.section > 0 {
            return defaultCellHeight
        }
        else if indexPath.row == 0 {
            var cellFont: UIFont = UIFont.boldSystemFontOfSize(18)
            var constraintSize: CGSize = CGSizeMake(self.view.bounds.size.width - 40, MAXFLOAT)
            var labelSize: CGSize = lblName.text!.boundingRectWithSize(constraintSize, options: ([.UsesLineFragmentOrigin, .UsesFontLeading]), attributes: [NSFontAttributeName: cellFont], context: nil).size
            return labelSize.height + 20
        }
        else if indexPath.row == 1 {
            var constraintSize: CGSize = CGSizeMake(self.view.bounds.size.width - 40, MAXFLOAT)
            var labelSize: CGSize = lblValue.text!.boundingRectWithSize(constraintSize, options: ([.UsesLineFragmentOrigin, .UsesFontLeading]), attributes: [NSFontAttributeName: CELL_TITLE_FONT], context: nil).size
            return labelSize.height + 20
        }
        else if indexPath.row == 2 {
            var cellFont: UIFont = UIFont.systemFontOfSize(16)
            var constraintSize: CGSize = CGSizeMake(self.view.bounds.size.width - 40, MAXFLOAT)
            var labelSize: CGSize = lblAscii.text!.boundingRectWithSize(constraintSize, options: ([.UsesLineFragmentOrigin, .UsesFontLeading]), attributes: [NSFontAttributeName: cellFont], context: nil).size
            return labelSize.height + 20
        }
        else if indexPath.row == 3 {
            var cellFont: UIFont = UIFont.systemFontOfSize(16)
            var constraintSize: CGSize = CGSizeMake(self.view.bounds.size.width - 40, MAXFLOAT)
            var labelSize: CGSize = lblProperties.text!.boundingRectWithSize(constraintSize, options: ([.UsesLineFragmentOrigin, .UsesFontLeading]), attributes: [NSFontAttributeName: cellFont], context: nil).size
            return labelSize.height + 20
        }
        else {
            return defaultCellHeight
        }

    }

    @IBAction func actionReload(sender: AnyObject) {
        requestTime = NSDate().timeIntervalSince1970
        characteristic.service.peripheral.readValueForCharacteristic(characteristic)
    }

    override func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
//
//  CharacteristicViewControllerViewController.m
//  BTLETools
//
//  Created by Tijn Kooijmans on 11-04-12.
//  Copyright (c) 2012 Studio Sophisti. All rights reserved.
//