//
//  CBService+Description.h
//  BTLETools
//
//  Created by Tijn Kooijmans on 14-11-12.
//
//
import CoreBluetooth
extension CBService {
    func serviceName() -> String {
        var title: String = "\(self.UUID)"
        var index: NSRange = title.rangeOfString("(<")
        if index.location != NSNotFound {
            if title.characters.count > 20 {
                // 128 bit uuid
                return "0x\(title.substringWithRange(NSMakeRange(index.location + 2, 35)))"
            }
            else {
                    // 16 bit uuid
                var key: String = "0x\(title.substringWithRange(NSMakeRange(index.location + 2, 4)).uppercaseString)"
                var value: String = NSLocalizedStringFromTable(key, "services", "")
                if (key == value) {
                    value = "Unknown UUID"
                }
                return "\(key): \(value)"
            }
        }
        return title.stringByReplacingOccurrencesOfString("Unknown", withString: "Unknown UUID:")
    }
}
//
//  CBService+Description.m
//  BTLETools
//
//  Created by Tijn Kooijmans on 14-11-12.
//
//